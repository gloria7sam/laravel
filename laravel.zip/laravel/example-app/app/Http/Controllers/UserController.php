<?php




namespace App\Http\Controllers;




use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;


class UserController extends Controller{

public function index(){


return view('users.home');

}


public function all_users(){

    $oMeuArray = [
        'nome' => 'Sara',
        'nome2' => 'José',
        'nome3' => 'Rúben',
    ];

    $allUsers = DB::table('users')
    ->get();


    file_put_contents("allUsers.txt", print_r($allUsers, true));

    $cesaeInfo = $this->getCesaeInfo();

return view('users.all_users', compact('oMeuArray', 'cesaeInfo', 'allUsers'));

}

public function addUsers(){

return view('users.add_users');

}

protected function getCesaeInfo(){
$cesaeInfo =
[
    'name' => 'Cesae',
    'address' => 'Rua Cenas',
    'email' => 'cenas@gmail.com',
];


return $cesaeInfo;

    return view('');
}

public function all_tasks(){
    $allTasks = $this->getAllTasks();
    return view('users.all_tasks', compact('allTasks'));
}

protected function getAllTasks(){

    $allTasks = DB::table('tasks')

    ->join('users', 'users.id', '=', 'tasks.user_id')
    ->select('tasks.*', 'users.name as usname')
    ->get();

    return $allTasks;
}

public function createUser(Request $request){

    $myUser = $request->all();

    $request->validate([
        'email' => 'required|email|unique:users',
        'name' => 'required|string',
        'password' => 'required'
    ]
    );

    User::insert([
        'email' => $request ->email,
        'name' => $request ->name,
        'password' => Hash::make($request ->password)
    ]);

    return redirect()->route('home_all_users')->with('message', 'Utilizador adicionado com sucesso');

    //file_put_contents("request.txt", print_r($myUser, true));
    }


    public function createTask(Request $request){

        $myUser = $request->all();
    
        $request->validate([
            'email' => 'required|email|unique:users',
            'name' => 'required|string',
            'password' => 'required'
        ]
        );
    
        User::insert([
            'email' => $request ->email,
            'name' => $request ->name,
            'password' => Hash::make($request ->password)
        ]);
    
        return redirect()->route('home_all_users')->with('message', 'Utilizador adicionado com sucesso');
    
        //file_put_contents("request.txt", print_r($myUser, true));
        }

        public function addTask(){

            return view('users.add_tasks');
            
            }
    

}






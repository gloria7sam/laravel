<?php

use App\Http\Controllers\HomeController;

use App\Http\Controllers\UserController;

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/hello_world', function() {
    return "<h1>Hello World</h1>";
});

Route::get('/hello1', function() {
    return "<h1>Hello 1</h1>";
});

Route::get('/hello', function() {
    return "<p>I am Glória. Welcome to my site!</p>";
});

Route::fallback(function(){
    return "<h1>Página não encontrada</h1>";

});

Route::get('/laravel-blade', function () {
    return view('my_laravel');
});

Route::get('/home', [UserController::class,
'index'] )->name('home');

Route::get('/home_users', [UserController::class,
'all_users'] )->name('show_all_users');

Route::get('/add_users', [UserController::class,
'addUsers'] )->name('show_add_users');

Route::get('/home_all_tasks', [UserController::class,
'all_tasks'] )->name('show_all_tasks');

Route::post('/create_user', [UserController::class,
'createUser'] )->name('create_user');

Route::post('/add_tasks', [UserController::class,
'createTask'] )->name('create_task');

Route::get('/add_tasks_users', [UserController::class,
'addTask'] )->name('add_tasks');



<?php

$myVar = 'Hello World';

echo $myVar;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blade</title>
</head>
<body>

<?php


/*$myVar = 'sou uma variável de PHP simples';
 echo $myVar; */

?>

@php
$myVarLaravel = 'sou uma variável de Php laravel';

@endphp

{{
    {
        $myVarLaravel
    }
}}

<h1>{{$myVarLaravel}}</h1>
</body>
</html>

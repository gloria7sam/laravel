

   @extends('layouts.main')

    @section('title')

    @section('content')
    <h1>Olá estou em casa!</h1>
    <ul>
        <a href="{{route('show_all_users')}}">
            <li>Todos os utilizadores</li>
        </a>
        <a href="{{route('show_add_users')}}">
            <li>Adicionar Utilizador</li>
        </a>
        <a href="{{route('create_task')}}">
            <li>Adicionar tarefas</li>
        </a>
        <a href="{{route('show_all_tasks')}}">
            <li>Todas as tarefas</li>
        </a>
        
</ul>
@endsection

@section('endcontent')
{{-- <h2>Sou o footer</h2> --}}

{{-- <p>{{$home['home']}}</p> --}}
@endsection

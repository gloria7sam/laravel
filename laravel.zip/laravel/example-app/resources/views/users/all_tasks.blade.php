@extends('layouts.main')

@section('content')
<div class="container">
    <h1>Olá, sou a lista de utilizadores</h1>

<div class="container">
<table class="table">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">Nome</th>
        <th scope="col">Descrição</th>
        <th scope="col">Status</th>
        <th scope="col">Nome Utilizador</th>
      </tr>
    </thead>
    <tbody>
        @foreach ($allTasks as $item)
        <tr>
            <th scope="row">{{$item->id}}</th>
            <td>{{$item->name}}</td>
            <td>{{$item->description}}</td>
            <td>{{$item->status}}</td>
            <td>{{$item->usname}}</td>
          </tr>
        @endforeach
    </tbody>
  </table>
</div>

<br>
<a href="{{route('home')}}">< Voltar</a>

@endsection

</div>

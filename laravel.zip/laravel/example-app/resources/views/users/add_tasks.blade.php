@extends('layouts.main')

@section('title')

@section('content')
    <h1 class="ms-5 text-center">Adicionar Task</h1>

    @if(session('message'))
    <div class="alert alert-success">{{session('message')}}</div>
    @endif

    <div class="mx-auto">
    <form method="POST" action="{{route('add_tasks')}}" class="bg-body-secondary w-50 justify-content-center mx-auto">
        @csrf
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Nome</label>
        <input class="form-control" name="nome" value="" id="nomeHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
        <input class="form-control" name="descricao" value="" id="descricaoHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Status</label>
        <input class="form-control" name="status" value="" id="statusHelp">
    </div>
    <br>
    <button class="btn btn-primary ms-5 mb-5">Submeter</button>

</form>
</div>
<br>
<a href="{{route('home')}}" class="ms-5">< Voltar</a>

<br>


@endsection

@section('endcontent')

@endsection

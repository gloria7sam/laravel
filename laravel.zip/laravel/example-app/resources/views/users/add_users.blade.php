
@extends('layouts.main')

@section('title')

@section('content')


    <h1 class="ms-5">Adicionar User</h1>

    @if(session('message'))

    <div class="alert alert-success">{{session('message')}}</div>
    @endif

    <form method="POST" action="{{route('create_user')}}">
        @csrf
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlInput1" class="form-label">Email</label>
        <input type="email" class="form-control" id="exampleInputName1" name="name" value="" id="exampleInputEmail1" placeholder="name@example.com" aria-describedby="emailHelp">

        @error('email')
        <div id="emailHelp" class="form-text">Insira um email válido</div>
        @enderror
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Nome</label>
        <input class="form-control" name="email" value="" id="emailHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
    <label for="inputPassword5" class="form-label">Password</label>
    <input type="password" name="password" id="inputPassword5" class="form-control" aria-labelledby="passwordHelpBlock">
    <div id="exampleInputPassword1" class="form-text">
    </div>
    <br>
    <button class="btn btn-primary">Submeter</button>
</form>
<br>
<br>
<a href="{{route('home')}}">< Voltar</a>

@endsection

@section('endcontent')

@endsection


<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>


    <h1 class="ms-5">Adicionar User</h1>

    <?php if(session('message')): ?>

    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('create_user')); ?>">
        <?php echo csrf_field(); ?>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlInput1" class="form-label">Email</label>
        <input type="email" class="form-control" id="exampleInputName1" name="name" value="" id="exampleInputEmail1" placeholder="name@example.com" aria-describedby="emailHelp">

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="emailHelp" class="form-text">Insira um email válido</div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Nome</label>
        <input class="form-control" name="email" value="" id="emailHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
    <label for="inputPassword5" class="form-label">Password</label>
    <input type="password" name="password" id="inputPassword5" class="form-control" aria-labelledby="passwordHelpBlock">
    <div id="exampleInputPassword1" class="form-text">
    </div>
    <br>
    <button class="btn btn-primary">Submeter</button>
</form>
<br>
<br>
<a href="<?php echo e(route('home')); ?>">< Voltar</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('endcontent'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sdev0223\Desktop\laravel\example-app\resources\views/users/add_users.blade.php ENDPATH**/ ?>
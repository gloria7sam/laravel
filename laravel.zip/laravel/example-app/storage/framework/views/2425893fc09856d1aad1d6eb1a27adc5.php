   

    <?php $__env->startSection('title'); ?>

    <?php $__env->startSection('content'); ?>
    <h1>Olá estou em casa!</h1>
    <ul>
        <a href="<?php echo e(route('show_all_users')); ?>">
            <li>Todos os utilizadores</li>
        </a>
        <a href="<?php echo e(route('show_add_users')); ?>">
            <li>Adicionar Utilizador</li>
        </a>
        <a href="<?php echo e(route('create_task')); ?>">
            <li>Adicionar tarefas</li>
        </a>
        <a href="<?php echo e(route('show_all_tasks')); ?>">
            <li>Todas as tarefas</li>
        </a>
        
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('endcontent'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sdev0223\Desktop\laravel\example-app\resources\views/users/home.blade.php ENDPATH**/ ?>
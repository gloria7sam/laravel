<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Olá, sou a lista de utilizadores</h1>

<div class="container">
<table class="table">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">Nome</th>
        <th scope="col">Descrição</th>
        <th scope="col">Status</th>
        <th scope="col">Nome Utilizador</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $allTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->description); ?></td>
            <td><?php echo e($item->status); ?></td>
            <td><?php echo e($item->usname); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sdev0223\Desktop\laravel\example-app\resources\views/users/all_tasks.blade.php ENDPATH**/ ?>
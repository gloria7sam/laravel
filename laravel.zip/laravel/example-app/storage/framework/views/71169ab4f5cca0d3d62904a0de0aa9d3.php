<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="ms-5 text-center">Adicionar Task</h1>

    <?php if(session('message')): ?>
    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <div class="mx-auto">
    <form method="POST" action="<?php echo e(route('add_tasks')); ?>" class="bg-body-secondary w-50 justify-content-center mx-auto">
        <?php echo csrf_field(); ?>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Nome</label>
        <input class="form-control" name="nome" value="" id="nomeHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
        <input class="form-control" name="descricao" value="" id="descricaoHelp">
    </div>
    <br>
    <div class="mb-3 ms-5 me-5">
        <label for="exampleFormControlTextarea1" class="form-label">Status</label>
        <input class="form-control" name="status" value="" id="statusHelp">
    </div>
    <br>
    <button class="btn btn-primary ms-5 mb-5">Submeter</button>

</form>
</div>
<br>
<a href="<?php echo e(route('home')); ?>" class="text-center">< Voltar</a>

<br>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('endcontent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sdev0223\Desktop\laravel\example-app\resources\views/users/add_tasks.blade.php ENDPATH**/ ?>